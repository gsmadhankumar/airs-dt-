import sys, time, numpy as np, torch
from multiprocessing import Pool
from common import *
from neural import *
CK = [500, 1000, 2000]
class Net:
    def __init__(self, sd, mappo):
        self.m = mlp(FD, 5); self.m.load_state_dict(sd); self.mappo = mappo
    def act(self, feat, train=False):
        with torch.no_grad(): return self.m(torch.from_numpy(feat)).argmax(-1).numpy().astype(np.int8)
def job(a):
    import os, json as js
    kind, seed = a
    fn = f"results/nn_{kind}_{seed}.json"
    if os.path.exists(fn): return js.load(open(fn))
    f = lambda sd: DTEnv(16, seed=sd, det=DETS["default"])
    ag, ck, tt = train_neural(kind, f, 2000, seed, CK)
    res = {c: summ(evaluate(NNPolicy(Net(ck[c], kind == "mappo"), kind), eval_env(seed))) for c in CK}
    dec = timed_decision_us(NNPolicy(Net(ck[2000], kind == "mappo"), kind))
    print("done", kind, seed, round(tt), flush=True)
    out = (kind, seed, res, tt, dec); js.dump(out, open(fn, "w")); return out
if __name__ == "__main__":
    seeds = [int(x) for x in sys.argv[1].split(",")]
    jobs = [(k, s) for s in seeds for k in ("iql", "vdn", "qmix", "mappo")]
    with Pool(int(sys.argv[2])) as p: out = p.map(job, jobs, chunksize=1)
    dump("neural_" + sys.argv[1].replace(",", "_"), out)
