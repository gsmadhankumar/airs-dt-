import numpy as np, time
from dtenv import DTEnv
from agents import *
class Noop:
    def reset(self,e):pass
    def act(self,e,x): return np.zeros(e.theta.shape,np.int8)
for name,P in [("noop",Noop()),("HBM",HBM()),("CRR",CRR())]:
    env=DTEnv(50,seed=1); t=time.time(); m=evaluate(P,env)
    print(name,{k:round(float(np.nanmean(v)),2) for k,v in m.items()},round(time.time()-t,2),"s")
