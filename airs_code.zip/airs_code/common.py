import numpy as np, json, time, os
from dtenv import DTEnv
from agents import *
DETS = {"perfect": (1.0, 0.0, 0.0), "default": (0.95, 0.003, 0.10), "degraded": (0.80, 0.010, 0.20)}
def summ(m):
    return {k: (float(np.nanmean(v)) if np.isfinite(v).any() else None) for k, v in m.items()}
def eval_env(seed, N=20, det="default", B=100, **kw):
    return DTEnv(B, N=N, seed=777000 + seed, det=DETS[det], **kw)
def timed_decision_us(policy, N=20, det="default", reps=60, seed=5):
    """wall-clock controller decision time per step for ONE environment (microseconds)"""
    env = DTEnv(1, N=N, seed=seed, det=DETS[det]); env.reset(); policy.reset(env)
    ts = []
    for _ in range(reps):
        t0 = time.perf_counter(); a = policy.act(env, env); ts.append(time.perf_counter() - t0)
        env.step(a)
    return float(np.median(ts) * 1e6)
def dump(name, obj):
    with open(f"results/{name}.json", "w") as f: json.dump(obj, f)
