import json, glob, numpy as np
from scipy import stats
METRICS = ["DET", "TMR", "ASR", "DRT", "SD", "ISO", "FISO", "RE", "CR", "SRS", "NACT"]
def load_main():
    return [json.load(open(f)) for f in sorted(glob.glob("results/main_[0-9]*.json"))]
def ms(vals):
    v = np.array([x for x in vals if x is not None], float)
    n = len(v)
    if n == 0: return None
    sd = v.std(ddof=1) if n > 1 else 0.0
    ci = stats.t.ppf(0.975, n - 1) * sd / np.sqrt(n) if n > 1 else 0.0
    return dict(mean=float(v.mean()), sd=float(sd), ci=float(ci), n=n, vals=[float(x) for x in v])
def welch(a, b):
    if a is None or b is None or a["n"] < 2 or b["n"] < 2: return None
    return float(stats.ttest_ind(a["vals"], b["vals"], equal_var=False).pvalue)
def build():
    M = load_main(); out = {"n_seeds_main": len(M)}
    CK = [str(c) for c in range(500, 5001, 500)]
    meth = {"AIRS": "airs", "SARL-single": "sarl_single", "SARL-factored": "sarl_factored"}
    main = {}
    for name, key in meth.items():
        main[name] = {m: ms([d[key]["2000"][m] for d in M]) for m in METRICS}
        main[name + " @5000"] = {m: ms([d[key]["5000"][m] for d in M]) for m in METRICS}
        main[name]["train_s"] = ms([(d[key + "_train_s"] if key != "airs" else d["airs_train_s"]) * 2000 / 5000 for d in M])
    for name in ("HBM", "CRR"):
        main[name] = {m: ms([d[name][m] for d in M]) for m in METRICS}
    # neural
    nn_files = glob.glob("results/nn_*.json"); neural = {}
    for f in nn_files:
        for kind, seed, res, tt, dec in [json.load(open(f))]:
            neural.setdefault(kind, {"seeds": {}, "train": [], "dec": []})
            neural[kind]["seeds"][seed] = res; neural[kind]["train"].append(tt); neural[kind]["dec"].append(dec)
    nname = {"iql": "IQL-DQN", "vdn": "VDN", "qmix": "QMIX", "mappo": "MAPPO"}
    for kind, d in neural.items():
        main[nname[kind]] = {m: ms([r["2000"][m] for r in d["seeds"].values()]) for m in METRICS}
        main[nname[kind]]["train_s"] = ms(d["train"]); main[nname[kind]]["dec_us"] = ms(d["dec"])
    out["main"] = main
    # budgets
    bud = {}
    for name, key in meth.items():
        bud[name] = {c: {m: ms([d[key][c][m] for d in M]) for m in ("ASR", "DRT", "SD", "CR", "RE", "SRS")} for c in ["500", "1000", "2000", "5000"]}
    for kind, d in neural.items():
        bud[nname[kind]] = {c: {m: ms([r[c][m] for r in d["seeds"].values()]) for m in ("ASR", "DRT", "SD", "CR", "RE", "SRS")} for c in ["500", "1000", "2000"]}
    out["budget"] = bud
    # curves (CR vs episodes) for tabular
    out["curve"] = {name: {c: ms([d[key][c]["CR"] for d in M]) for c in CK} for name, key in meth.items()}
    out["curve_ASR"] = {name: {c: ms([d[key][c]["ASR"] for d in M]) for c in CK} for name, key in meth.items()}
    # significance vs strongest learned-or-rule baseline by CR
    base = [k for k in main if k != "AIRS" and "@" not in k]
    best = max(base, key=lambda k: main[k]["CR"]["mean"])
    out["best_baseline"] = best
    out["pvals"] = {k: {m: welch(main["AIRS"][m], main[k][m]) for m in METRICS} for k in base}
    out["pvals5000"] = {k: {m: welch(main["AIRS @5000"][m], main[k][m]) for m in METRICS} for k in base}
    # other groups
    for g in ("abl", "det"):
        try: out[g + "_raw"] = json.load(open(f"results/{g}.json"))
        except Exception: pass
    sf = sorted(glob.glob("results/sc_*.json"))
    if sf: out["scale_raw"] = [json.load(open(f)) for f in sf]
    if "abl_raw" in out:
        ab = {}
        for _, name, seed, m in out["abl_raw"]: ab.setdefault(name, []).append(m)
        out["abl"] = {n: {m: ms([x[m] for x in v]) for m in ("ASR", "DRT", "SD", "CR", "RE", "FISO")} for n, v in ab.items()}
        out["abl_p"] = {n: welch(out["abl"][n]["CR"], out["abl"]["airs_default"]["CR"]) for n in ab if n != "airs_default"}
        out["abl_p_asr"] = {n: welch(out["abl"][n]["ASR"], out["abl"]["airs_default"]["ASR"]) for n in ab if n != "airs_default"}
        out["abl_p_drt"] = {n: welch(out["abl"][n]["DRT"], out["abl"]["airs_default"]["DRT"]) for n in ab if n != "airs_default"}
    if "det_raw" in out:
        dd = {}
        for _, det, seed, r in out["det_raw"]:
            for meth_, m in r.items(): dd.setdefault(det, {}).setdefault(meth_, []).append(m)
        out["det"] = {det: {k: {m: ms([x[m] for x in v]) for m in ("DET", "TMR", "ASR", "DRT", "SD", "FISO", "CR")} for k, v in d.items()} for det, d in dd.items()}
    if "scale_raw" in out:
        sc = {}
        for _, N, seed, r in out["scale_raw"]:
            for meth_, m in r.items(): sc.setdefault(N, {}).setdefault(meth_, []).append(m)
        out["scale"] = {N: {k: {m: ms([x.get(m) for x in v]) for m in ("TMR", "ASR", "DRT", "SD", "CR", "train_s", "dec_us")} for k, v in d.items()} for N, d in sc.items()}
    tf = sorted(glob.glob("results/nnteam_iql_*.json"))
    if tf:
        T_ = [json.load(open(f))[2] for f in tf]
        out["iql_team"] = {m: ms([r[m] for r in T_]) for m in ("ASR", "DRT", "SD", "CR", "RE", "FISO", "SRS")}
        out["iql_team_p"] = {m: welch(out["iql_team"][m], main["IQL-DQN"][m]) for m in ("ASR", "DRT", "SD", "CR", "RE", "FISO")}
    if "det" in out:
        out["det_p_airs_cr"] = {d: welch(out["det"][d]["AIRS"]["CR"], main["AIRS"]["CR"]) for d in out["det"]}
        out["det_p_airs_fiso"] = {d: welch(out["det"][d]["AIRS"]["FISO"], main["AIRS"]["FISO"]) for d in out["det"]}
    if "scale" in out:
        out["scale_p"] = {N: {m: welch(d["AIRS (trained at N)"][m], d["AIRS (trained at N=20)"][m]) for m in ("ASR", "DRT", "CR")} for N, d in out["scale"].items()}
    return out
if __name__ == "__main__":
    o = build()
    for k in [k for k in o if k.endswith("_raw")]: del o[k]
    def clean(x):
        if isinstance(x, dict): return {k: clean(v) for k, v in x.items()}
        if isinstance(x, list): return [clean(v) for v in x]
        if isinstance(x, float) and x != x: return None
        return x
    json.dump(clean(o), open("results/stats.json", "w"))
    print("seeds", o["n_seeds_main"])
    for k, v in o["main"].items():
        print(k, {m: (round(v[m]["mean"], 1) if v.get(m) else None) for m in ("ASR", "DRT", "SD", "CR", "RE", "SRS", "FISO")})
