import time, numpy as np
from common import *
from neural import *
f=lambda sd: DTEnv(16,seed=sd)
for kind in ("iql","vdn","qmix","mappo"):
    t=time.time()
    ag,ck,tt=train_neural(kind,f,160,0,ckpts=(160,))
    print(kind,"train s",round(tt,1),flush=True)
