import numpy as np, time
from dtenv import EFF, COST, DUR

# ---------------- rule-based baselines ----------------
class HBM:
    """Heuristic-based method: local threshold rule on the observed threat level."""
    name = "HBM"
    def reset(self, env): pass
    def act(self, env, obs_env):
        th, busy = obs_env.th_hat, obs_env.busy
        a = np.zeros(th.shape, np.int8)
        a[(th > 0.3)] = 3
        a[(th > 0.6)] = 1
        a[busy] = 0
        return a

class CRR:
    """Centralised rule-based response: playbook keyed on alert class; controller sees telemetry one step late
    and dispatches actions one step later (two-step control latency)."""
    name = "CRR"
    RULE = {1: 3, 2: 3, 3: 2, 4: 1}   # DoS->access control, FDI->access control, MITM->reconfigure, Malware->isolate
    def reset(self, env):
        self.prev = None; self.queue = None
    def act(self, env, e):
        cur = (e.cls.copy(), e.th_hat.copy(), e.busy.copy())
        seen = self.prev if self.prev is not None else (np.zeros_like(cur[0]), np.zeros_like(cur[1]), np.zeros_like(cur[2]))
        self.prev = cur
        cls, th, busy = seen
        a = np.zeros(cls.shape, np.int8)
        for c, act in self.RULE.items():
            a[(cls == c) & (th > 0.1) & ~busy] = act
        out = self.queue if self.queue is not None else np.zeros_like(a)
        self.queue = a
        return out

# ---------------- tabular learners ----------------
class TabularQ:
    """Tabular Q-learning on discretised local observations.
    mode='airs'  : shared Q over local observations, one action per node per step (decentralised execution)
    """
    def __init__(self, n_states, eta=0.1, gamma=0.99, cap=200000, batch=256, replay=True, seed=0, init=0.0):
        self.Q = np.full((n_states, 5), init, np.float32)
        self.eta, self.gamma, self.cap, self.batch, self.replay = eta, gamma, cap, batch, replay
        self.rng = np.random.default_rng(seed)
        self.mem = [np.zeros(cap, np.int32), np.zeros(cap, np.int8), np.zeros(cap, np.float32), np.zeros(cap, np.int32)]
        self.ptr = 0; self.size = 0
        self.eps = 1.0
    def greedy(self, s):
        q = self.Q[s]
        best = q.max(-1, keepdims=True)
        # random tie-breaking among maximisers
        noise = self.rng.random(q.shape) * 1e-6
        return (q + noise).argmax(-1).astype(np.int8)
    def act(self, s, train=True):
        a = self.greedy(s)
        if train:
            m = self.rng.random(s.shape) < self.eps
            a = np.where(m, self.rng.integers(0, 5, s.shape), a).astype(np.int8)
        return a
    def store(self, s, a, r, s2):
        s, a, r, s2 = [x.ravel() for x in (s, a, r, s2)]
        n = len(s)
        idx = (self.ptr + np.arange(n)) % self.cap
        self.mem[0][idx], self.mem[1][idx], self.mem[2][idx], self.mem[3][idx] = s, a, r, s2
        self.ptr = (self.ptr + n) % self.cap
        self.size = min(self.size + n, self.cap)
    def update(self, last=None):
        if self.replay:
            i = self.rng.integers(0, self.size, self.batch)
            s, a, r, s2 = [m[i] for m in self.mem]
        else:
            s, a, r, s2 = [x.ravel() for x in last]
        tgt = r + self.gamma * self.Q[s2].max(1)
        d = tgt - self.Q[s, a]
        flat = s.astype(np.int64) * 5 + a
        sm = np.bincount(flat, weights=d, minlength=self.Q.size)
        ct = np.bincount(flat, minlength=self.Q.size)
        self.Q += (self.eta * sm / np.maximum(ct, 1)).reshape(self.Q.shape).astype(np.float32)

def train_airs(env_factory, episodes, seed, replay=True, ckpts=(), eps_decay=None, eta=0.1, gamma=0.99,
               B=16, n_states=2500, eval_fn=None, log=None):
    """Train shared-parameter independent Q-learners. Environments are run B at a time (B episodes per round)."""
    ag = TabularQ(n_states, eta=eta, gamma=gamma, replay=replay, seed=seed)
    rounds = int(np.ceil(episodes / B))
    decay = eps_decay if eps_decay is not None else 0.95
    out = {}; curve = []
    t0 = time.time()
    done_eps = 0
    for rd in range(rounds):
        env = env_factory(seed * 100003 + rd)
        s = env.reset()
        ret = np.zeros(env.B)
        for _ in range(env.T):
            a = ag.act(s)
            s2, r, R, dn = env.step(a)
            ag.store(s, a, r, s2)
            ag.update((s, a, r, s2))
            ret += R
            s = s2
        ag.eps = max(0.05, ag.eps * decay)
        done_eps += env.B
        curve.append((done_eps, env.cr.mean()))
        for c in ckpts:
            if done_eps >= c and c not in out:
                out[c] = ag.Q.copy()
                if log: log(f"seed {seed} ckpt {c} t={time.time()-t0:.0f}s")
    return ag, out, curve, time.time() - t0

class GreedyPolicy:
    name = "AIRS"
    def __init__(self, Q, seed=0):
        self.ag = TabularQ(Q.shape[0], seed=seed); self.ag.Q = Q
    def reset(self, env): pass
    def act(self, env, e): return self.ag.greedy(e.obs)

def evaluate(policy, env):
    s = env.reset(); policy.reset(env)
    for _ in range(env.T):
        a = policy.act(env, env)
        env.step(a)
    return env.metrics()


# ---------------- single-agent RL baselines ----------------
class SARL:
    """Centralised learners with one-step telemetry delay and the team (global) reward.
    kind='single'   : one controller selecting ONE (most-threatened node, action) pair per step
    kind='factored' : one controller issuing a per-node action at every step (shared table over local obs + global context)"""
    def __init__(self, kind, eta=0.1, gamma=0.99, seed=0):
        self.kind = kind
        self.q = TabularQ(2500 * 4, eta=eta, gamma=gamma, seed=seed)
        self.prev = None
    @property
    def Q(self): return self.q.Q
    def reset(self, env): self.prev = None
    def _state(self, e):
        """state index built from the observation of the PREVIOUS step (telemetry delay)"""
        cur = (e.obs.copy(), e.th_hat.copy(), e.alert.copy())
        seen = self.prev if self.prev is not None else cur
        self.prev = cur
        obs, th, al = seen
        n_al = np.minimum(al.sum(1), 3)                 # number of alerted nodes (0..3+)
        if self.kind == "single":
            sel = th.argmax(1)
            b = np.arange(obs.shape[0])
            s = obs[b, sel] * 4 + n_al
            return s, sel
        tot = th.sum(1) / th.shape[1]
        g = np.minimum((tot * 20).astype(np.int32), 3)  # global threat context (4 buckets)
        return obs * 4 + g[:, None], None
    def policy_act(self, e, train=False):
        s, sel = self._state(e)
        a_raw = self.q.act(s, train=train)
        if self.kind == "single":
            a = np.zeros(e.theta.shape, np.int8)
            a[np.arange(a.shape[0]), sel] = a_raw
            a[e.busy] = 0
            return a, s, a_raw
        a = a_raw.copy(); a[e.busy] = 0
        return a, s, a_raw
    def act(self, env, e): return self.policy_act(e)[0]

def train_sarl(kind, env_factory, episodes, seed, ckpts=(), B=16, gamma=0.99, log=None):
    ag = SARL(kind, gamma=gamma, seed=seed)
    rounds = int(np.ceil(episodes / B)); out = {}; t0 = time.time(); done = 0
    for rd in range(rounds):
        env = env_factory(seed * 100003 + rd); env.reset(); ag.reset(env)
        for _ in range(env.T):
            a, s, a_raw = ag.policy_act(env, train=True)
            env.step(a)
            # next state uses the (delayed) telemetry; compute without advancing the delay buffer
            saved = ag.prev; s2, _ = ag._state(env); ag.prev = saved
            R = env.R
            if kind == "single":
                ag.q.store(s, a_raw, R, s2); ag.q.update((s, a_raw, R, s2))
            else:
                Rn = np.repeat(R[:, None], env.N, 1)
                ag.q.store(s, a_raw, Rn, s2); ag.q.update((s, a_raw, Rn, s2))
        ag.q.eps = max(0.05, ag.q.eps * 0.95); done += env.B
        for c in ckpts:
            if done >= c and c not in out: out[c] = ag.q.Q.copy()
    return ag, out, time.time() - t0

class SARLPolicy:
    def __init__(self, kind, Q, seed=0):
        self.ag = SARL(kind, seed=seed); self.ag.q.Q = Q
        self.name = "SARL-" + kind
    def reset(self, env): self.ag.reset(env)
    def act(self, env, e): return self.ag.policy_act(e)[0]
