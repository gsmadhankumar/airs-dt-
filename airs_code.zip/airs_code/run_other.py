import sys, numpy as np, time
from multiprocessing import Pool
from common import *
EP = 2000
VARS = {"airs_default": {}, "no_replay": dict(replay=False), "global_reward": dict(lam=1.0), "no_alert_info": dict(mask_alert=True),
        "alpha_x2": dict(w=(2.0, 2.0, 1.0)), "beta_x2": dict(w=(1.0, 4.0, 1.0)), "delta_x2": dict(w=(1.0, 2.0, 2.0)), "delta_x0.5": dict(w=(1.0, 2.0, 0.5))}
def abl_job(a):
    name, seed = a; v = dict(VARS[name]); replay = v.pop("replay", True)
    f = lambda sd: DTEnv(16, seed=sd, det=DETS["default"], **v)
    ag, ck, curve, tt = train_airs(f, EP, seed, replay=replay, ckpts=(EP,))
    kw = {"mask_alert": True} if v.get("mask_alert") else {}
    m = summ(evaluate(GreedyPolicy(ck[EP]), eval_env(seed, **kw)))
    return ("abl", name, seed, m)
def det_job(a):
    det, seed = a
    f = lambda sd: DTEnv(16, seed=sd, det=DETS[det])
    ag, ck, curve, tt = train_airs(f, EP, seed, ckpts=(EP,))
    r = {"AIRS": summ(evaluate(GreedyPolicy(ck[EP]), eval_env(seed, det=det)))}
    ag2, ck2, tt2 = train_sarl("factored", f, EP, seed, ckpts=(EP,))
    r["SARL-factored"] = summ(evaluate(SARLPolicy("factored", ck2[EP]), eval_env(seed, det=det)))
    r["HBM"] = summ(evaluate(HBM(), eval_env(seed, det=det)))
    r["CRR"] = summ(evaluate(CRR(), eval_env(seed, det=det)))
    return ("det", det, seed, r)
def scale_job(a):
    import os, json as js
    N, seed = a
    fn = f"results/sc_{N}_{seed}.json"
    if os.path.exists(fn): return tuple(js.load(open(fn)))
    EP = 1000
    f = lambda sd: DTEnv(16, N=N, seed=sd)
    f20 = lambda sd: DTEnv(16, N=20, seed=sd)
    ev = lambda: eval_env(seed, N=N, B=50)
    r = {}
    ag, ck, curve, tt = train_airs(f, EP, seed, ckpts=(EP,))
    pol = GreedyPolicy(ck[EP]); r["AIRS (trained at N)"] = summ(evaluate(pol, ev())); r["AIRS (trained at N)"]["train_s"] = tt
    r["AIRS (trained at N)"]["dec_us"] = timed_decision_us(pol, N=N)
    ag, ck20, curve, tt = train_airs(f20, EP, seed, ckpts=(EP,))
    pol = GreedyPolicy(ck20[EP]); r["AIRS (trained at N=20)"] = summ(evaluate(pol, ev()))
    ag, cks, tt = train_sarl("single", f, EP, seed, ckpts=(EP,))
    pol = SARLPolicy("single", cks[EP]); r["SARL-single"] = summ(evaluate(pol, ev())); r["SARL-single"]["train_s"] = tt; r["SARL-single"]["dec_us"] = timed_decision_us(pol, N=N)
    for P in (HBM(), CRR()):
        r[P.name] = summ(evaluate(P, ev())); r[P.name]["dec_us"] = timed_decision_us(P, N=N)
    js.dump(["scale", N, seed, r], open(fn, "w")); return ("scale", N, seed, r)
if __name__ == "__main__":
    which = sys.argv[1]
    if which == "abl": jobs = [(n, s) for n in VARS for s in range(10)]; fn = abl_job
    elif which == "det": jobs = [(d, s) for d in ("perfect", "degraded") for s in range(10)]; fn = det_job
    else: jobs = [(N, s) for N in (50, 100, 200) for s in range(10)]; fn = scale_job
    with Pool(2) as p: res = p.map(fn, jobs, chunksize=1)
    dump(which, res); print("done", which)
