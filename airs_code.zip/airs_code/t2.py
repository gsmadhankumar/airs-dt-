import numpy as np, time, sys
from dtenv import DTEnv
from agents import *
ep=int(sys.argv[1]) if len(sys.argv)>1 else 1000
f=lambda sd: DTEnv(16,seed=sd)
t=time.time()
ag,ck,curve,tt=train_airs(f,ep,seed=0,ckpts=(ep,))
print("train time",round(tt,1))
m=evaluate(GreedyPolicy(ag.Q),DTEnv(50,seed=999))
print({k:round(float(np.nanmean(v)),2) for k,v in m.items()})
print([round(c[1],1) for c in curve[::max(1,len(curve)//10)]])
