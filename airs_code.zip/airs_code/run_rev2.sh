#!/bin/bash
cd /home/claude/airs_code
python3 run_iqlteam.py >> results/rev2.log 2>&1
rm -f results/scale.json
python3 run_other.py scale >> results/rev2.log 2>&1
echo REV2DONE >> results/rev2.log
