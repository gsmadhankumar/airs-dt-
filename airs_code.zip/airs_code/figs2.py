import json, numpy as np, matplotlib
matplotlib.use("Agg")
import matplotlib.pyplot as plt
from matplotlib.patches import FancyBboxPatch, Rectangle
plt.rcParams.update({"font.family": "serif", "font.serif": ["Times New Roman", "Liberation Serif", "DejaVu Serif"], "font.size": 9, "mathtext.fontset": "stix"})
S = json.load(open("results/stats.json"))
OUT = "../figs/"
import os; os.makedirs(OUT, exist_ok=True)
# ---------- Fig 1 architecture ----------
fig, ax = plt.subplots(figsize=(7.2, 3.1)); ax.set_xlim(0, 100); ax.set_ylim(-8, 44); ax.axis("off")
def box(x, y, w, h, t, fc):
    ax.add_patch(FancyBboxPatch((x, y), w, h, boxstyle="round,pad=0.3,rounding_size=1.2", fc=fc, ec="#444", lw=0.9)); ax.text(x + w / 2, y + h / 2, t, ha="center", va="center", fontsize=8)
def arr(x1, y1, x2, y2): ax.annotate("", xy=(x2, y2), xytext=(x1, y1), arrowprops=dict(arrowstyle="-|>", lw=0.9, color="#222"))
box(2, 34, 22, 8, "Physical layer\nIoT devices, sensors", "#d9f2d0"); box(2, 21, 22, 8, "Digital twin layer\nstate synchronisation", "#d6d9f7")
box(2, 8, 22, 8, "Communication layer\ndata exchange", "#fbe0c6"); box(2, -4, 22, 8, "Security control layer\nMARL agents", "#f6cfd6")
arr(13, 34, 13, 29.3); arr(13, 21, 13, 16.3); arr(13, 8, 13, 4.3)
ax.add_patch(Rectangle((35, 6), 63, 34, fill=False, ls="--", ec="#444", lw=0.9)); ax.text(66, 41, "MARL module (one agent per node, shared parameters)", ha="center", fontsize=8.5)
box(38, 28, 16, 8, "Local observation\n$o_t^i=(h,\\theta,\\kappa,c,n,b)$", "#f6cfd6"); box(62, 28, 14, 8, "Agent $i$\n$Q(o,a)$", "#f6cfd6"); box(82, 28, 14, 8, "Action\n$a_t^i\\in\\mathcal{A}$", "#f6cfd6")
box(38, 10, 16, 8, "Detector alert $c_t^i$,\nneighbour alert $n_t^i$", "#fff4b8"); box(62, 10, 14, 8, "Neighbourhood\nreward $r_t^i$", "#f6cfd6"); box(82, 10, 14, 8, "Q-update\n(replay)", "#f6cfd6")
arr(54, 32, 61.7, 32); arr(76, 32, 81.7, 32); arr(89, 28, 89, 18.3); arr(82, 14, 76.3, 14); arr(62, 14, 54.3, 14); arr(46, 18.3, 46, 27.7)
arr(24.3, 25, 37.7, 32); arr(24.3, 4, 37.7, 12)
ax.plot([66, 66, 25], [6, 0, 0], color="#222", lw=0.9); ax.annotate("", xy=(24.4, 0), xytext=(28, 0), arrowprops=dict(arrowstyle="-|>", lw=0.9, color="#222"))
ax.text(46, -3, "response actions applied to the DT environment", fontsize=7.5, ha="center", style="italic")
fig.savefig(OUT + "fig1.png", dpi=300, bbox_inches="tight"); plt.close(fig)
# ---------- Fig 2 comparison ----------
order = [m for m in ["HBM", "CRR", "SARL-single", "SARL-factored", "IQL-DQN", "VDN", "QMIX", "MAPPO", "AIRS"] if m in S["main"]]
fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.7))
for a, (m, yl, lab) in zip(axs, [("ASR", "Attack success rate (%)", "(a)"), ("DRT", "Detection-to-suppression (ms)", "(b)"), ("CR", "Cumulative reward", "(c)")]):
    mu = [S["main"][k][m]["mean"] for k in order]; sd = [S["main"][k][m]["sd"] for k in order]
    col = ["#2f5d9e" if k == "AIRS" else "#9aa5b1" for k in order]
    a.bar(range(len(order)), mu, yerr=sd, color=col, edgecolor="#222", lw=0.5, capsize=2, error_kw=dict(lw=0.7))
    a.set_xticks(range(len(order))); a.set_xticklabels(order, rotation=60, ha="right", fontsize=7)
    a.set_ylabel(yl, fontsize=8); a.spines[["top", "right"]].set_visible(False); a.set_xlabel(lab, fontsize=8)
    a.set_ylim(0, None)
fig.tight_layout(); fig.savefig(OUT + "fig2.png", dpi=300); plt.close(fig)
# ---------- Fig 3 learning curves ----------
fig, axs = plt.subplots(1, 2, figsize=(7.2, 2.7))
cols = {"AIRS": "#2f5d9e", "SARL-single": "#c0504d", "SARL-factored": "#9b7a2f"}
for a, key, yl, lab in [(axs[0], "curve", "Cumulative reward (evaluation)", "(a)"), (axs[1], "curve_ASR", "Attack success rate (%)", "(b)")]:
    for name in ["AIRS", "SARL-single", "SARL-factored"]:
        xs = sorted(int(c) for c in S[key][name]); mu = np.array([S[key][name][str(c)]["mean"] for c in xs]); sd = np.array([S[key][name][str(c)]["sd"] for c in xs])
        a.plot(xs, mu, "-o", ms=3, lw=1.2, color=cols[name], label=name); a.fill_between(xs, mu - sd, mu + sd, color=cols[name], alpha=0.18, lw=0)
    for name, mk in [("IQL-DQN", "s"), ("VDN", "^"), ("QMIX", "v"), ("MAPPO", "D")]:
        if name in S["budget"]:
            xs = [500, 1000, 2000]; mm = "CR" if key == "curve" else "ASR"
            a.plot(xs, [S["budget"][name][str(c)][mm]["mean"] for c in xs], mk + "--", ms=3, lw=0.8, label=name, alpha=0.8)
    a.set_xlabel("Training episodes\n" + lab, fontsize=8); a.set_ylabel(yl, fontsize=8); a.grid(alpha=0.3); a.spines[["top", "right"]].set_visible(False)
axs[0].legend(fontsize=6, ncol=2, frameon=False)
fig.tight_layout(); fig.savefig(OUT + "fig3.png", dpi=300); plt.close(fig)
# ---------- Fig 4 scalability ----------
if "scale" in S:
    from matplotlib.ticker import NullFormatter, NullLocator
    Ns = sorted(int(n) for n in S["scale"]); fig, axs = plt.subplots(1, 3, figsize=(7.4, 2.8))
    STY = {"AIRS (trained at N)": ("#2f5d9e", "o", "AIRS (trained at N)"), "AIRS (trained at N=20)": ("#e07b00", "s", "AIRS (trained at N = 20)"),
           "SARL-single": ("#7b4fa3", "^", "SARL-single"), "HBM": ("#2e8b57", "v", "HBM"), "CRR": ("#c0392b", "D", "CRR")}
    for a, (m, yl, lab, logy) in zip(axs, [("ASR", "Attack success rate (%)", "(a)", False), ("train_s", "Training time (s)", "(b)", True), ("dec_us", "Decision time per step (\u00b5s)", "(c)", True)]):
        for k, (c, mk, nm) in STY.items():
            pts = [(n, S["scale"][str(n)][k][m]["mean"]) for n in Ns if S["scale"][str(n)][k].get(m)]
            if pts:
                xs, ys = zip(*pts); a.plot(xs, ys, "-" + mk, ms=3.5, lw=1.1, color=c, label=nm)
        a.set_xscale("log"); a.set_xticks(Ns); a.set_xticklabels([str(n) for n in Ns])
        a.xaxis.set_minor_locator(NullLocator()); a.xaxis.set_minor_formatter(NullFormatter())
        a.set_xlabel("Number of nodes N\n" + lab, fontsize=8); a.set_ylabel(yl, fontsize=8)
        if logy: a.set_yscale("log")
        a.grid(alpha=0.3); a.spines[["top", "right"]].set_visible(False)
    h, l = axs[0].get_legend_handles_labels()
    fig.legend(h, l, loc="lower center", ncol=5, fontsize=6.5, frameon=False, bbox_to_anchor=(0.5, -0.01))
    fig.tight_layout(rect=(0, 0.1, 1, 1)); fig.savefig(OUT + "fig4.png", dpi=300); plt.close(fig)
print("figs ok")
