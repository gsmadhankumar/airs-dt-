#!/bin/bash
cd /home/claude/airs_code
[ -f results/main_9.json ] || python3 run_main.py >> results/main.log 2>&1
python3 run_neural.py 0,1,2,3,4 2 >> results/neural.log 2>&1
[ -f results/abl.json ] || python3 run_other.py abl >> results/other.log 2>&1
[ -f results/det.json ] || python3 run_other.py det >> results/other.log 2>&1
[ -f results/scale.json ] || python3 run_other.py scale >> results/other.log 2>&1
echo ALLDONE >> results/other.log
