import numpy as np, json, torch
from common import *
from neural import *
from run_neural import Net
res = {}
tq = np.random.default_rng(0).normal(size=(2500, 5)).astype(np.float32)
for name, P in [("AIRS", GreedyPolicy(tq)), ("SARL-single", SARLPolicy("single", np.random.default_rng(0).normal(size=(10000, 5)).astype(np.float32))),
                ("SARL-factored", SARLPolicy("factored", np.random.default_rng(0).normal(size=(10000, 5)).astype(np.float32))), ("HBM", HBM()), ("CRR", CRR())]:
    res[name] = timed_decision_us(P)
for kind in ("iql", "vdn", "qmix", "mappo"):
    net = mlp(FD, 5); sd = {k: v for k, v in net.state_dict().items()}
    nm = {"iql": "IQL-DQN", "vdn": "VDN", "qmix": "QMIX", "mappo": "MAPPO"}[kind]
    res[nm] = timed_decision_us(NNPolicy(Net(sd, kind == "mappo"), kind))
json.dump(res, open("results/timing.json", "w")); print(res)
