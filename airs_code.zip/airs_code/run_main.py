import sys, numpy as np, time, json
from multiprocessing import Pool
from common import *
CK = list(range(500, 5001, 500))
def job(seed):
    import os
    if os.path.exists(f"results/main_{seed}.json"): return
    out = {"seed": seed}
    f = lambda sd: DTEnv(16, seed=sd, det=DETS["default"])
    t = time.time()
    ag, ck, curve, tt = train_airs(f, 5000, seed, ckpts=CK)
    out["airs"] = {c: summ(evaluate(GreedyPolicy(ck[c]), eval_env(seed))) for c in CK}
    out["airs_train_s"] = tt
    out["airs_curve"] = [(int(a), float(b)) for a, b in curve]
    for kind in ("single", "factored"):
        ag, ck, tt = train_sarl(kind, f, 5000, seed, ckpts=CK)
        out["sarl_" + kind] = {c: summ(evaluate(SARLPolicy(kind, ck[c]), eval_env(seed))) for c in CK}
        out["sarl_" + kind + "_train_s"] = tt
    out["HBM"] = summ(evaluate(HBM(), eval_env(seed)))
    out["CRR"] = summ(evaluate(CRR(), eval_env(seed)))
    dump(f"main_{seed}", out); print("done", seed, round(time.time() - t), flush=True)
if __name__ == "__main__":
    seeds = list(range(10))
    with Pool(2) as p: p.map(job, seeds, chunksize=1)
