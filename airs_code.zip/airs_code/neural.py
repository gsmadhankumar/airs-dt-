"""Deep MARL baselines on the same local observations: IQL-DQN, VDN, QMIX (value-based) and MAPPO (actor-critic).
All use parameter sharing across the N homogeneous agents and the same schedule (eps 0.95 per round of 16 episodes)."""
import numpy as np, torch, torch.nn as nn, torch.nn.functional as F, time
from dtenv import DTEnv
torch.set_num_threads(1)
FD = 10
def mlp(i, o, h=64): return nn.Sequential(nn.Linear(i, h), nn.ReLU(), nn.Linear(h, h), nn.ReLU(), nn.Linear(h, o))

class QMixer(nn.Module):
    def __init__(self, n, sd, emb=32):
        super().__init__(); self.n, self.emb = n, emb
        self.w1 = nn.Sequential(nn.Linear(sd, 64), nn.ReLU(), nn.Linear(64, n * emb)); self.b1 = nn.Linear(sd, emb)
        self.w2 = nn.Sequential(nn.Linear(sd, 64), nn.ReLU(), nn.Linear(64, emb)); self.b2 = nn.Sequential(nn.Linear(sd, 32), nn.ReLU(), nn.Linear(32, 1))
    def forward(self, q, s):                        # q [M,n], s [M,sd]
        w1 = self.w1(s).abs().view(-1, self.n, self.emb); b1 = self.b1(s).unsqueeze(1)
        h = F.elu(torch.bmm(q.unsqueeze(1), w1) + b1)
        w2 = self.w2(s).abs().unsqueeze(2); b2 = self.b2(s).unsqueeze(1)
        return (torch.bmm(h, w2) + b2).view(-1)

class ValueMARL:
    def __init__(self, kind, N, seed, gamma=0.99, lr=1e-3, cap=60000, batch=128):
        torch.manual_seed(seed); self.rng = np.random.default_rng(seed)
        self.kind, self.N, self.gamma, self.batch, self.cap = kind, N, gamma, batch, cap
        self.q = mlp(FD, 5); self.qt = mlp(FD, 5); self.qt.load_state_dict(self.q.state_dict())
        params = list(self.q.parameters())
        if kind == "qmix":
            self.mix = QMixer(N, N * FD); self.mixt = QMixer(N, N * FD); self.mixt.load_state_dict(self.mix.state_dict()); params += list(self.mix.parameters())
        self.opt = torch.optim.Adam(params, lr=lr); self.eps = 1.0; self.ptr = 0; self.size = 0; self.nup = 0
        if kind == "iql":      # agent-level transitions
            self.buf = [np.zeros((cap, FD), np.float32), np.zeros(cap, np.int64), np.zeros(cap, np.float32), np.zeros((cap, FD), np.float32)]
        else:                  # joint transitions
            self.buf = [np.zeros((cap, N, FD), np.float32), np.zeros((cap, N), np.int64), np.zeros(cap, np.float32), np.zeros((cap, N, FD), np.float32)]
    def act(self, feat, train=False):
        with torch.no_grad():
            q = self.q(torch.from_numpy(feat))
            a = q.argmax(-1).numpy()
        if train:
            m = self.rng.random(a.shape) < self.eps
            a = np.where(m, self.rng.integers(0, 5, a.shape), a)
        return a.astype(np.int8)
    def store(self, f, a, r_loc, R, f2):
        B, N = a.shape
        if self.kind == "iql": f, a, r, f2 = f.reshape(-1, FD), a.ravel(), r_loc.ravel(), f2.reshape(-1, FD); n = len(a)
        else: r, n = R, B
        idx = (self.ptr + np.arange(n)) % self.cap
        self.buf[0][idx], self.buf[1][idx], self.buf[2][idx], self.buf[3][idx] = f, a, r, f2
        self.ptr = (self.ptr + n) % self.cap; self.size = min(self.size + n, self.cap)
    def update(self):
        bs = self.batch * (4 if self.kind == "iql" else 1)
        i = self.rng.integers(0, self.size, bs)
        f, a, r, f2 = [torch.from_numpy(x[i]) for x in self.buf]
        if self.kind == "iql":
            qa = self.q(f).gather(1, a[:, None]).squeeze(1)
            with torch.no_grad(): tgt = r + self.gamma * self.qt(f2).max(1)[0]
        else:
            qa = self.q(f).gather(2, a[..., None]).squeeze(2)
            with torch.no_grad(): qn = self.qt(f2).max(2)[0]
            if self.kind == "vdn": qa, qn = qa.sum(1), qn.sum(1)
            else: qa = self.mix(qa, f.flatten(1)); qn = self.mixt(qn, f2.flatten(1))
            tgt = r + self.gamma * qn
        loss = F.mse_loss(qa, tgt)
        self.opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(self.q.parameters(), 10); self.opt.step()
        self.nup += 1
        if self.nup % 100 == 0:
            self.qt.load_state_dict(self.q.state_dict())
            if self.kind == "qmix": self.mixt.load_state_dict(self.mix.state_dict())

class MAPPO:
    def __init__(self, N, seed, gamma=0.99, lam=0.95, lr=5e-4):
        torch.manual_seed(seed); self.rng = np.random.default_rng(seed)
        self.N, self.gamma, self.lam = N, gamma, lam
        self.pi = mlp(FD, 5); self.v = mlp(N * FD, 1, 128)
        self.opt = torch.optim.Adam(list(self.pi.parameters()) + list(self.v.parameters()), lr=lr)
    def act(self, feat, train=False):
        with torch.no_grad():
            lg = self.pi(torch.from_numpy(feat))
            a = torch.distributions.Categorical(logits=lg).sample().numpy() if train else lg.argmax(-1).numpy()
        return a.astype(np.int8)
    def logp(self, feat, a):
        lg = self.pi(feat); d = torch.distributions.Categorical(logits=lg); return d.log_prob(a), d.entropy()
    def learn(self, F_, A_, R_, V_, last_v):
        T, B = R_.shape[:2]
        adv = np.zeros((T, B), np.float32); g = 0
        for t in reversed(range(T)):
            nv = last_v if t == T - 1 else V_[t + 1]
            d = R_[t] + self.gamma * nv - V_[t]; g = d + self.gamma * self.lam * g; adv[t] = g
        ret = adv + V_
        f = torch.from_numpy(F_.reshape(T * B, self.N, FD)); a = torch.from_numpy(A_.reshape(T * B, self.N).astype(np.int64))
        advt = torch.from_numpy(((adv - adv.mean()) / (adv.std() + 1e-8)).reshape(-1)); rett = torch.from_numpy(ret.reshape(-1))
        with torch.no_grad(): old, _ = self.logp(f, a)
        n = T * B
        for _ in range(4):
            perm = self.rng.permutation(n)
            for mb in np.array_split(perm, 8):
                mb = torch.from_numpy(mb)
                lp, ent = self.logp(f[mb], a[mb])
                ratio = torch.exp(lp - old[mb]); ad = advt[mb][:, None]
                pl = -torch.min(ratio * ad, torch.clamp(ratio, 0.8, 1.2) * ad).mean()
                vl = F.mse_loss(self.v(f[mb].flatten(1)).squeeze(1), rett[mb])
                loss = pl + 0.5 * vl - 0.01 * ent.mean()
                self.opt.zero_grad(); loss.backward(); nn.utils.clip_grad_norm_(self.pi.parameters(), 10); self.opt.step()

class NNPolicy:
    def __init__(self, ag, name): self.ag, self.name = ag, name
    def reset(self, env): pass
    def act(self, env, e): return self.ag.act(e.feat)

def train_neural(kind, env_factory, episodes, seed, ckpts, N=20, B=16, snapshot=None):
    """returns dict ckpt->state_dict snapshot and train seconds. snapshot(ag)->object to store."""
    ag = MAPPO(N, seed) if kind == "mappo" else ValueMARL(kind, N, seed)
    rounds = int(np.ceil(episodes / B)); out = {}; t0 = time.time(); done = 0
    for rd in range(rounds):
        env = env_factory(seed * 100003 + rd); env.reset(); T = env.T
        if kind == "mappo":
            Fb, Ab, Rb, Vb = [], [], [], []
        for t in range(T):
            f = env.feat.copy(); a = ag.act(f, train=True)
            if kind == "mappo":
                with torch.no_grad(): Vb.append(ag.v(torch.from_numpy(f.reshape(env.B, -1))).squeeze(1).numpy())
            env.step(a)
            if kind == "mappo": Fb.append(f); Ab.append(a); Rb.append(env.R.copy())
            else:
                ag.store(f, a.astype(np.int64), env.r_train, env.R, env.feat.copy())
                if ag.size > 2000 and t % 2 == 0: ag.update()
        if kind == "mappo":
            with torch.no_grad(): lv = ag.v(torch.from_numpy(env.feat.reshape(env.B, -1))).squeeze(1).numpy()
            ag.learn(np.stack(Fb), np.stack(Ab), np.stack(Rb), np.stack(Vb), lv)
        else: ag.eps = max(0.05, ag.eps * 0.95)
        done += env.B
        for c in ckpts:
            if done >= c and c not in out:
                net = ag.pi if kind == "mappo" else ag.q
                out[c] = {k: v.clone() for k, v in net.state_dict().items()}
    return ag, out, time.time() - t0
