"""IQL-DQN trained on the team reward (lambda = 1): isolates the effect of the neighbourhood reward for deep agents."""
import sys, os, json as js
from multiprocessing import Pool
from common import *
from neural import *
from run_neural import Net
def job(seed):
    fn = f"results/nnteam_iql_{seed}.json"
    if os.path.exists(fn): return js.load(open(fn))
    f = lambda sd: DTEnv(16, seed=sd, det=DETS["default"], lam=1.0)
    ag, ck, tt = train_neural("iql", f, 2000, seed, [2000])
    res = summ(evaluate(NNPolicy(Net(ck[2000], False), "iql"), eval_env(seed)))
    out = ("iql_team", seed, res, tt); js.dump(out, open(fn, "w")); print("done", seed, round(tt), flush=True); return out
if __name__ == "__main__":
    with Pool(2) as p: p.map(job, range(5), chunksize=1)
