"""Vectorised digital-twin (DT) incident-response simulator used for the AIRS experiments.
All B environments are stepped simultaneously with numpy. See Appendix A of the paper for the full specification."""
import numpy as np, warnings
warnings.filterwarnings('ignore', category=RuntimeWarning)

FAM = ["DoS", "FDI", "MITM", "Malware"]
ACT = ["noop", "isolate", "reconfigure", "access_control", "migrate"]
# threat reduction per step while a response action is in progress, EFF[family, action]
EFF = np.array([[0, .35, .15, .55, .05],
                [0, .40, .05, .50, .10],
                [0, .35, .55, .05, .10],
                [0, .65, .15, .05, .35]], dtype=np.float32)
COST = np.array([0, .60, .30, .20, .50], dtype=np.float32)       # cost incurred when an action is initiated
DUR = np.array([0, 10, 5, 5, 3], dtype=np.int32)                 # steps an initiated action stays in progress
GROW = np.array([.25, .12, .18, .15], dtype=np.float32)           # per-step threat injection per unit intensity
STEP_MS = 20.0


class DTEnv:
    def __init__(self, B, N=20, T=250, seed=0, det=(0.95, 0.003, 0.10), mask_alert=False,
                 w=(1.0, 2.0, 1.0), lam=0.0, k=4, p_rewire=0.1):
        self.B, self.N, self.T = B, N, T
        self.rng = np.random.default_rng(seed)
        self.p_d, self.p_fp, self.conf = det
        self.mask_alert = mask_alert
        self.alpha, self.beta, self.delta = w
        self.lam = lam
        self.k, self.p_rewire = k, p_rewire
        self.scale = max(1, N // 20)
        self.K = 3 * self.scale
        self.n_states = 5 * 5 * 5 * 5 * 2 * 2

    # ---------------- topology ----------------
    def _topology(self):
        B, N, k = self.B, self.N, self.k
        A = np.zeros((B, N, N), dtype=np.float32)
        idx = np.arange(N)
        for d in range(1, k // 2 + 1):
            A[:, idx, (idx + d) % N] = 1
        for b in range(B):
            ii, jj = np.nonzero(A[b])
            rew = self.rng.random(len(ii)) < self.p_rewire
            for i, j in zip(ii[rew], jj[rew]):
                new = self.rng.integers(N)
                if new != i and A[b, i, new] == 0:
                    A[b, i, j] = 0
                    A[b, i, new] = 1
        A = np.maximum(A, A.transpose(0, 2, 1))
        return A

    def reset(self):
        B, N = self.B, self.N
        r = self.rng
        self.A = self._topology()
        self.deg = self.A.sum(2)
        self.t = 0
        self.theta = np.zeros((B, N), np.float32)
        self.fam = -np.ones((B, N), np.int8)
        self.h = np.ones((B, N), np.float32)
        self.kap = np.ones((B, N), np.float32)
        self.act_t = np.zeros((B, N), np.int8)
        self.timer = np.zeros((B, N), np.int32)
        self.init_theta = np.zeros((B, N), np.float32)
        self.fail_t = -np.ones((B, N), np.int32)
        self.fail_fam = -np.ones((B, N), np.int8)
        self.affected = np.zeros((B, N), bool)
        # attacks
        K = self.K
        nat = r.integers(1, 4, size=B) * self.scale
        self.a_valid = np.arange(K)[None, :] < nat[:, None]
        self.a_fam = r.integers(0, 4, size=(B, K)).astype(np.int8)
        self.a_t0 = r.integers(10, 81, size=(B, K))
        self.a_dur = r.integers(40, 101, size=(B, K))
        self.a_int = r.uniform(0.6, 1.0, size=(B, K)).astype(np.float32)
        self.a_tgt = r.integers(0, N, size=(B, K))
        nb = np.zeros((B, K), int)
        for b in range(B):
            for kk in range(K):
                nz = np.nonzero(self.A[b, self.a_tgt[b, kk]])[0]
                nb[b, kk] = r.choice(nz) if len(nz) else self.a_tgt[b, kk]
        self.a_tgt2 = nb
        self.a_det = -np.ones((B, K), np.int32)
        self.a_supp = -np.ones((B, K), np.int32)
        self.a_high = np.zeros((B, K), bool)
        self.a_cont = -np.ones((B, K), np.int32)
        # statistics
        self.stat_unavail = np.zeros((B, N), np.float32)
        self.stat_iso = np.zeros((B, N), np.float32)
        self.n_iso_init = np.zeros(B)
        self.n_false_iso = np.zeros(B)
        self.n_act = np.zeros(B)
        self.n_act_eff = np.zeros(B)
        self.n_resp = np.zeros(B)
        self.n_resp_eff = np.zeros(B)
        self.cr = np.zeros(B)
        self.R_hist = []
        self._make_obs()
        return self.obs

    # ---------------- observation ----------------
    def _make_obs(self):
        B, N = self.B, self.N
        r = self.rng
        thr = self.theta > 0.1
        tp = thr & (r.random((B, N)) < self.p_d)
        fp = (~thr) & (r.random((B, N)) < self.p_fp)
        alert = tp | fp
        cls = np.where(self.fam >= 0, self.fam, r.integers(0, 4, size=(B, N)))
        wrong = r.random((B, N)) < self.conf
        cls = np.where(wrong, (cls + r.integers(1, 4, size=(B, N))) % 4, cls)
        cls = np.where(fp, r.integers(0, 4, size=(B, N)), cls)
        c = np.where(alert, cls + 1, 0).astype(np.int8)
        nb = (np.einsum('bij,bj->bi', self.A, alert.astype(np.float32)) > 0)
        busy = self.timer > 0
        th_hat = np.clip(self.theta + r.normal(0, 0.08, (B, N)), 0, 1).astype(np.float32)
        if self.mask_alert:
            c = np.zeros_like(c); nb = np.zeros_like(nb)
        self.alert = alert
        self.cls, self.nb, self.busy, self.th_hat = c, nb, busy, th_hat
        lv = lambda x: np.minimum((x * 5).astype(np.int32), 4)
        s = lv(self.h)
        s = s * 5 + lv(th_hat)
        s = s * 5 + lv(self.kap)
        s = s * 5 + c.astype(np.int32)
        s = s * 2 + nb.astype(np.int32)
        s = s * 2 + busy.astype(np.int32)
        self.obs = s
        # continuous features for neural agents
        feat = np.concatenate([self.h[..., None], th_hat[..., None], self.kap[..., None],
                               np.eye(5, dtype=np.float32)[c], nb[..., None].astype(np.float32),
                               busy[..., None].astype(np.float32)], axis=-1)
        self.feat = feat.astype(np.float32)

    # ---------------- dynamics ----------------
    def step(self, actions):
        B, N, t = self.B, self.N, self.t
        r = self.rng
        a = actions.astype(np.int8)
        init = (a > 0) & (self.timer == 0)
        self.act_t = np.where(init, a, self.act_t)
        self.timer = np.where(init, DUR[a], self.timer)
        self.init_theta = np.where(init, self.theta, self.init_theta)
        cost = np.where(init, COST[a], 0).astype(np.float32)
        # bookkeeping for isolation / responses
        self.n_act += init.sum(1)
        iso_init = init & (a == 1)
        self.n_iso_init += iso_init.sum(1)
        self.n_false_iso += (iso_init & (self.theta < 0.05)).sum(1)
        # alerts seen by the agents at this step -> attack detection times
        bidx = np.arange(B)
        for k in range(self.K):
            tg = self.a_tgt[:, k]
            ok = self.a_valid[:, k] & (self.a_det[:, k] < 0) & (t >= self.a_t0[:, k])
            hit = ok & self.alert[bidx, tg] & (self.theta[bidx, tg] > 0.1)
            self.a_det[hit, k] = t
        # response effect
        inprog = self.timer > 0
        famc = np.maximum(self.fam, 0)
        red = EFF[famc, self.act_t.astype(np.int32)] * (inprog & (self.fam >= 0))
        self.theta = np.maximum(self.theta - red, 0)
        iso = inprog & (self.act_t == 1)
        mig = inprog & (self.act_t == 4)
        acc = inprog & (self.act_t == 3)
        rec = inprog & (self.act_t == 2)
        # attack injection
        for k in range(self.K):
            act = self.a_valid[:, k] & (t >= self.a_t0[:, k]) & (t < self.a_t0[:, k] + self.a_dur[:, k])
            if not act.any():
                continue
            f = self.a_fam[:, k]
            for j, tg in enumerate((self.a_tgt[:, k], self.a_tgt2[:, k])):
                blocked = iso[bidx, tg]
                share = 1.0 if j == 0 else (f == 2) * 0.5          # MITM also hits a neighbouring node
                g = GROW[f] * self.a_int[:, k] * np.where(acc[bidx, tg], 0.5, 1.0) * share
                g = np.where(act & ~blocked, g, 0).astype(np.float32)
                new_fam = (self.fam[bidx, tg] < 0) | (self.theta[bidx, tg] < 0.05)
                self.theta[bidx, tg] = np.minimum(self.theta[bidx, tg] + g, 1.0)
                setf = (g > 0) & new_fam
                self.fam[bidx[setf], tg[setf]] = f[setf]
            fdi = act & (f == 1)
            if fdi.any():
                tg = self.a_tgt[:, k]
                nbm = self.A[bidx, tg] > 0
                self.kap[fdi] -= (0.03 * self.theta[bidx, tg][fdi, None]) * nbm[fdi]
        # malware propagation
        mal = (self.fam == 3) & (self.theta > 0.2) & ~iso
        p = 0.30 * self.theta * mal * np.where(rec, 0.5, 1.0)
        P = 1 - np.exp(-np.einsum('bij,bi->bj', self.A, p))
        vuln = ((self.fam < 0) | (self.theta < 0.05)) & ~iso
        inf = vuln & (r.random((B, N)) < P)
        self.theta = np.where(inf, self.theta + 0.2, self.theta)
        self.fam = np.where(inf, 3, self.fam).astype(np.int8)
        # decay and health / trust
        self.theta = np.clip(self.theta - 0.005, 0, 1).astype(np.float32)
        clear = self.theta < 0.02
        self.theta[clear] = 0
        self.fam[clear] = -1
        self.h = np.clip(self.h - 0.10 * self.theta + 0.008 * (self.theta < 0.1), 0, 1).astype(np.float32)
        self.kap = np.clip(self.kap - 0.08 * self.theta + 0.01 * (1 - self.kap), 0, 1).astype(np.float32)
        newfail = (self.h < 0.3) & (self.fail_t < 0)
        self.fail_t[newfail] = t
        self.fail_fam[newfail] = self.fam[newfail]
        self.affected |= self.h < 0.6
        unavail = iso | mig | (self.h < 0.3)
        # timers and effectiveness bookkeeping
        was = self.timer > 0
        self.timer = np.maximum(self.timer - 1, 0)
        expired = was & (self.timer == 0)
        hi = expired & (self.init_theta > 0.1)
        self.n_resp += hi.sum(1)
        self.n_resp_eff += (hi & (self.theta < self.init_theta - 0.05)).sum(1)
        # attack bookkeeping (suppression / containment)
        malany = ((self.fam == 3) & (self.theta > 0.05)).any(1)
        for k in range(self.K):
            tg = self.a_tgt[:, k]
            th = self.theta[bidx, tg]
            started = self.a_valid[:, k] & (t >= self.a_t0[:, k])
            self.a_high[:, k] |= started & (th > 0.1)
            supp = started & self.a_high[:, k] & (th <= 0.1) & (self.a_supp[:, k] < 0) & (self.a_det[:, k] >= 0)
            self.a_supp[supp, k] = t
            ended = self.a_valid[:, k] & (t >= self.a_t0[:, k] + self.a_dur[:, k]) & (self.a_cont[:, k] < 0)
            ok = ended & (th < 0.05) & ~((self.a_fam[:, k] == 3) & malany)
            self.a_cont[ok, k] = t
        # rewards
        Theta = self.theta.sum(1)
        M = 1 - np.minimum(1, Theta / (3.0 * self.scale))
        D = unavail.mean(1)
        C = cost.mean(1) / 0.6
        R = self.alpha * M - self.beta * D - self.delta * C
        nbm = self.A + np.eye(N, dtype=np.float32)[None]
        th_loc = np.einsum('bij,bj->bi', nbm, self.theta)
        un_loc = np.einsum('bij,bj->bi', nbm, unavail.astype(np.float32)) / nbm.sum(2)
        M_l = 1 - np.minimum(1, th_loc / 2.0)
        r_loc = self.alpha * M_l - self.beta * un_loc - self.delta * cost / 0.6
        self.r_loc = r_loc.astype(np.float32)
        self.R = R.astype(np.float32)
        self.r_train = ((1 - self.lam) * self.r_loc + self.lam * self.R[:, None]).astype(np.float32)
        self.cr += (0.99 ** t) * R
        self.stat_unavail += unavail
        self.stat_iso += iso
        self.t += 1
        self._make_obs()
        return self.obs, self.r_train, self.R, self.t >= self.T

    # ---------------- episode metrics ----------------
    def metrics(self):
        B = self.B
        valid = self.a_valid
        n_tot = valid.sum(1)
        det = valid & (self.a_det >= 0)
        cont = valid & (self.a_cont >= 0)
        # failures attributed to attacks
        succ = np.zeros_like(valid)
        for k in range(self.K):
            win_end = np.where(self.a_cont[:, k] >= 0, self.a_cont[:, k], self.T)
            ff = (self.fail_t >= 0) & (self.fail_fam == self.a_fam[:, k][:, None]) & \
                 (self.fail_t >= self.a_t0[:, k][:, None]) & (self.fail_t <= win_end[:, None])
            succ[:, k] = valid[:, k] & (ff.any(1) | (self.a_cont[:, k] < 0))
        drt = np.where(det & (self.a_supp >= 0), (self.a_supp - self.a_det) * STEP_MS, np.nan)
        aff = self.affected.sum(1)
        rec = (self.affected & (self.h >= 0.9)).sum(1)
        out = dict(
            TMR=100 * (det & cont).sum(1) / np.maximum(det.sum(1), 1),
            DET=100 * det.sum(1) / np.maximum(n_tot, 1),
            ASR=100 * succ.sum(1) / np.maximum(n_tot, 1),
            DRT=np.nanmean(np.where(np.isnan(drt), np.nan, drt), axis=1) if np.isfinite(drt).any() else np.full(B, np.nan),
            SD=self.stat_unavail.mean(1) * STEP_MS / 1000.0,
            ISO=100 * self.stat_iso.mean(1) / self.T,
            FISO=100 * self.n_false_iso / np.maximum(self.n_iso_init, 1),
            RE=100 * self.n_resp_eff / np.maximum(self.n_resp, 1),
            CR=self.cr.copy(),
            SRS=np.where(aff > 0, 100 * rec / np.maximum(aff, 1), np.nan),
            NACT=self.n_act / self.N,
        )
        return out
