import numpy as np,time
from dtenv import DTEnv
from agents import *
f=lambda sd: DTEnv(16,seed=sd)
for kind in ("single","factored"):
    ag,ck,tt=train_sarl(kind,f,1000,0,ckpts=(1000,))
    m=evaluate(SARLPolicy(kind,ck[1000]),DTEnv(100,seed=999))
    print(kind,round(tt,1),{k:round(float(np.nanmean(v)),2) for k,v in m.items()})
